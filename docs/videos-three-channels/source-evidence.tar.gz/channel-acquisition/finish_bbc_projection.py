import json,re,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));import classify
rows=json.load(open(R/'bbc-recoverable.json'));ov=json.load(open(R/'overrides.json'));mods=0
explicit={'vn_0zspXbj0':'Annie Mac','itCO7dXXXKo':'Heather Small','EbIJKAYIRZg':'Wet Leg','SzWkwAZ2MIg':'Kate Nash e Soft Play','mzf47LI8Zmg':'Owl In The Sun'}
exclude={'GGeqPQ_U8dM','P2ph7Saoqm8','jekirhekHUo','utxWHcprH4Q','3vYjEs16WeI','5y6aA7nWuho','7Y-hTqly35c','lEtI6X9igQo','mA2cgKVk08w','wynZTARQqzI'}
for v in rows:
 q=classify.classify('bbc',v);i=v['id'];t=v['title']
 if i in exclude:ov[i]={'eligible':False,'reason':'Contextual title identifies industry discussion, artist retrospective, festival scenery/tour/promotion or preparation rather than the performance'};mods+=1;continue
 if not q['eligible']:continue
 artist=q['artist'];title=q['title']
 clean=re.sub(r'BBC(?: Music)?(?: Introducing)?(?: Radio [1-6])?\s*:?\s*','',t,flags=re.I).strip()
 m=re.match(r"(.+?)(?: performing |'s surprise (?:set|performance) )(.+)",clean)
 if m:artist=m[1];title=m[2]
 elif re.match(r'New Music Fix Live:',clean):
  m=re.match(r'New Music Fix Live:\s*(.+?)\s+-\s+(.+)',clean)
  if m:artist=m[1];title=m[2]
 elif re.match(r'(.+?) at Reading Festival',artist):artist=re.match(r'(.+?) at Reading Festival',artist)[1]
 if i in explicit:artist=explicit[i]
 artist=artist.lstrip(' :@').strip()
 if artist!=q['artist'] or title!=q['title']:ov[i]=dict(q,artist=artist,title=title);mods+=1
(R/'overrides.json').write_text(json.dumps(ov,ensure_ascii=False,indent=2));print('metadata projection fixes',mods)
