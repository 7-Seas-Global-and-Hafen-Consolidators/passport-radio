import json,re
from pathlib import Path
from classify import records,classify,date
r=Path(__file__).parent;ov=json.loads((r/'overrides.json').read_text())
for v in records('wackentv'):
 t=v['title'];i=v['id'];q=classify('wackentv',v)
 if t.startswith("Maschine's Late Night Show"):
  q.update(artist='Maschine e convidados',title=t,type='program',evidence='Published complete live episode of the festival late-night programme')
  ov[i]=q
 if i in ['rPkhjjHEnCc','YnJ1D6OqGP8','rljw_UkGW5M','f6D4tnd1nF8','7rUv8eK1jQI','mJEYOj-puQ8','UHucHq08HOk','S1AaHmBZyuE','P1FqiFjALkY','nnDw4RncdJI','ZvBXrxc7DBM']:
  ov[i]={'eligible':False,'reason':'Description reviewed: promotional DVD announcement, talk/report, scenery or celebratory montage; separately published performances remain eligible'}
 if i in ['ai0pa82ypb4','z7B6go0nhVU','iIHg1et1VfM']:
  d=json.loads((r/'watch'/(i+'.json')).read_text())['details']['shortDescription']; artists=[]
  for line in d.splitlines():
   m=re.match(r'\d+:\d+:\d+\s+(.+?)\s+[-–]',line)
   if m and m[1].strip() not in artists:artists.append(m[1].strip())
  ov[i]=dict(q,artist=', '.join(artists[:4])+(' e outros' if len(artists)>4 else ''),title=t.split(' - ')[0]+' · Wacken Open Air',type='program',showDate=None,evidence='Acquired description contains full multi-artist live compilation and timestamped performance credits')
(r/'overrides.json').write_text(json.dumps(ov,ensure_ascii=False,indent=2))
