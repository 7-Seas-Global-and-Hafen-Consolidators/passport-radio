import yt_dlp,json,os,concurrent.futures,time
from pathlib import Path
r=Path(__file__).parent;out=r/'playlist-entries';out.mkdir(exist_ok=True)
jobs=[]
for n in ['wackentv','midnight','bbc']:
 d=json.loads((r/(n+'-playlists.json')).read_text());jobs.extend((n,x) for x in d['entries'])
def go(job):
 n,x=job;p=out/(x['id']+'.json')
 if p.exists():return
 class Log:
  def debug(self,m):pass
  def warning(self,m):print(n,x['id'],'WARNING',m,flush=True)
  def error(self,m):pass
 try:
  with yt_dlp.YoutubeDL({'extract_flat':True,'skip_download':True,'proxy':os.environ['HTTPS_PROXY'],'socket_timeout':20,'retries':2,'extractor_retries':2,'logger':Log()}) as y:d=y.extract_info(x['url'],download=False)
  p.write_text(json.dumps({'source':n,'directoryEntry':x,'playlist':d},ensure_ascii=False));print(n,x['id'],len(d.get('entries',[])),'DONE',flush=True)
 except Exception as e:(out/(x['id']+'.error')).write_text(str(e));print(n,x['id'],'FAIL',str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:list(ex.map(go,jobs))
print('PLAYLISTS FINISHED',len(jobs),flush=True)
