import json,time,concurrent.futures,os
from pathlib import Path
import yt_dlp
ROOT=Path(__file__).parent
channels={'wackentv':'https://youtube.com/@wackentv?si=W4O8TaXJXFJBW_IG','midnight':'https://youtube.com/@themidnightspecialtvshow?si=dOxQTR4vbHsC3dBA','bbc':'https://youtube.com/@bbcmusic?si=8V0vqb9Aj1UJe8yZ'}
def run(name,url):
 target=ROOT/(name+'-channel.json')
 if target.exists(): return name,'cached'
 class Logger:
  def debug(self,msg):
   print(name,msg,flush=True)
  def warning(self,msg):print(name,'WARNING',msg,flush=True)
  def error(self,msg):print(name,'ERROR',msg,flush=True)
 opts={'skip_download':True,'extract_flat':True,'ignoreerrors':False,'socket_timeout':30,'retries':3,'extractor_retries':3,'logger':Logger(),'proxy':os.environ['HTTPS_PROXY']}
 try:
  with yt_dlp.YoutubeDL(opts) as y: info=y.extract_info(url,download=False)
  target.write_text(json.dumps(info,ensure_ascii=False)); print(name,'DONE',len(info.get('entries',[])),flush=True)
 except Exception as e:
  (ROOT/(name+'-error.txt')).write_text(str(e)); print(name,'FAILED',str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(lambda kv:run(*kv),channels.items()))
