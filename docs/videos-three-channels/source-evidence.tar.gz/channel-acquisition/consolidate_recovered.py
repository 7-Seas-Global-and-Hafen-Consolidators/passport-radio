import json,sys,re,hashlib,collections
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));import classify
repo=R.parent/'videos-channels';base=json.loads((R/'baseline-catalogue.json').read_text());cat=json.loads((R.parent/'recovered-checkpoint/data/passport-videos.json').read_text());old=json.loads((R.parent/'recovered-checkpoint/data/passport-videos-channel-audit.json').read_text());audit=old['records'];counts=old['summary']['sources'];assert cat['videos'][:106]==base['videos'];assert cat['collections'][:4]==base['collections']
rows=json.loads((R/'bbc-recoverable.json').read_text());seen={v['id'] for v in cat['videos']};original={v['id'] for v in base['videos']};c={'traversed':len(rows),'eligible':0,'alreadyExisting':0,'added':0,'excluded':0,'duplicatesAvoided':0};col='sessions-archive';cat['collections'].append({'id':col,'label':'Sessões e festivais'})
for pos,v in enumerate(rows,1):
 q=classify.classify('bbc',v);assert q['eligible'] is not None,(v['id'],v['title']);rec={'id':v['id'],'source':'bbc','channelId':v.get('channel_id') or classify.CHANNELS['bbc'],'originalUrl':'https://www.youtube.com/watch?v='+v['id'],'originalTitle':v['title'],'memberships':v.get('memberships',[]),'classification':q,'uploader':v.get('uploader') or v.get('channel'),'acquisitionChannel':'BBC Music','acquiredMetadata':v,'contextEvidenceFile':('watch/'+v['id']+'.json') if (R/'watch'/(v['id']+'.json')).exists() else None}
 if not q['eligible']:c['excluded']+=1;rec['disposition']='excluded'
 else:
  c['eligible']+=1
  if v['id'] in seen:
   c['duplicatesAvoided']+=1;rec['disposition']='already-present'
   if v['id'] in original:c['alreadyExisting']+=1
  else:
   title=q['title'];artist=q['artist']
   title=re.sub(r'BBC(?: Music)?(?: Introducing)?(?: Radio [1-6])?(?: Sounds)?|YouTube|WackenTV','',title,flags=re.I).strip(' |–-')
   if not title or not artist:raise ValueError(v['id'])
   cat['videos'].append({'id':v['id'],'artist':artist,'title':title,'showDate':q.get('showDate'),'type':q['type'],'collections':[col],'collectionOrder':{col:pos},'embedAllowed':True,'thumbnail':'https://img.youtube.com/vi/'+v['id']+'/hqdefault.jpg'});seen.add(v['id']);c['added']+=1;rec['disposition']='added'
 audit.append(rec)
counts['bbc']=c
summary={'baseHead':'72c76dbbbf32e1d3b63a6dc0f84f4c463a3c3fc7','baselineCount':106,'finalCount':len(cat['videos']),'sources':counts,'playlistsCompleted':223,'bbcRecovery':{'playlistRecordsRecovered':4031,'shortsListed':479,'recoverableDistinctIds':len(rows),'shortsTraversalComplete':True,'videosTraversedBeforeInterruption':6444,'unsavedVideosTabRecovered':False,'scopeLimitation':'Missing standalone Videos-tab records cannot be reconstructed from the surviving checkpoints. Videos tab was not traversed again. Catalogue contains all classified recoverable records, not a claim of complete historical BBC-channel coverage.'},'limits':['Actual provider playback is subject to availability; no global guarantee inferred from metadata.','Items with insufficient identity remain internal, with the exclusion reason.']}
assert cat['videos'][:106]==base['videos'];assert len(cat['videos'])==len({v['id'] for v in cat['videos']})
(repo/'docs/videos-three-channels').mkdir(parents=True,exist_ok=True)
for f,d in [('data/passport-videos.json',cat),('data/passport-videos-channel-audit.json',{'summary':summary,'records':audit}),('docs/videos-three-channels/counts.json',summary)]: (repo/f).write_text(json.dumps(d,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
