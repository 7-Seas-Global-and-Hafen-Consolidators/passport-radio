import json,re,sys
from pathlib import Path
R=Path(__file__).parent;sys.path.insert(0,str(R));import classify
rows=json.loads((R/'bbc-recoverable.json').read_text());ov=json.loads((R/'overrides.json').read_text())
norm=lambda s:re.sub(r'[^a-z0-9]','',s.lower())
known={norm(a):a for a in ['Emma Harbs','Sorley','Jude Lawless','Mia Lily','Niamh','Lulu','Cast','Carly Rae Jepsen','Sombr','Slayyyter','Adéla','Laufey','Macy Gray','Madness','Tony Christie','CMAT','Hayla','Zaho de Sagazan','Blood Orange','Rylan','Pale Waves','Good Neighbours','Issey Cross','Jade','Lola Young','10cc','Pulp','RAYE','Def Leppard','Sophie Ellis-Bextor','Conan Gray','ArrDee','James Blunt','Jonas Brothers','Thirty Seconds to Mars','Bristol Reggae Orchestra','Sigur Rós']}
for v in rows:
 q=classify.classify('bbc',v)
 if q['eligible'] and len(q['artist'])>2 and len(q['artist'])<65:known.setdefault(norm(q['artist']),q['artist'])
changes={};pending=[]
for v in rows:
 q=classify.classify('bbc',v)
 if q['eligible'] is not None:continue
 t=v['title'];p=R/'watch'/(v['id']+'.json');d=json.loads(p.read_text()) if p.exists() else {};desc=d.get('details',{}).get('shortDescription','');head=desc.split('\n\n')[0]
 text=t+' '+head
 if re.search(r'Thursday Tip|Masterclass|wins? the|winner of|breaks down|meets|in [234] minutes|Road to|Theatre|Circus|site build|School of Zen|spiritual|tour of|Pangea|Worthy Farm|talk|interview|Backstage|behind the scenes|subscribe|trailer|teaser',text,re.I):
  changes[v['id']]={'eligible':False,'reason':'Acquired title/context identifies non-performance or promotional material'};continue
 matches=sorted([a for key,a in known.items() if len(key)>=3 and key in norm(t)],key=len,reverse=True)
 m=re.match(r'(.+?)\s+perfom(?:s)?\s+on\s+(.+)',t,re.I)
 if m:artist=m[1];title=m[2]
 elif matches and re.search(r'perform|Live|Later|Jools|Glastonbury|PianoRoom|Piano Room|Hootenanny|festival|BigWeekend|R2InThePark|session|DJSet|sing|cover|#Reading|stage|Proms',text,re.I):
  artist=matches[0];title=re.sub(r'\bBBC(?: Music)?(?: Radio [1-6])?(?: Introducing)?\b','',t,flags=re.I).strip()
  title=re.sub(r'@\S+|#BBCIntroducing','',title).strip()
 else:pending.append(v['id']);continue
 changes[v['id']]={'eligible':True,'artist':artist,'title':title,'type':'performance','showDate':classify.date(t),'evidence':'Artist identified in acquired title; musical performance corroborated by acquired title/description; no upload date substituted'}
ov.update(changes);(R/'overrides.json').write_text(json.dumps(ov,ensure_ascii=False,indent=2));(R/'bbc-unresolved.json').write_text(json.dumps([v for v in rows if v['id'] in pending],ensure_ascii=False,indent=2));print('resolved',len(changes),'remaining',len(pending));print('\n'.join(v['id']+' '+v['title'] for v in rows if v['id'] in pending))
