import json,subprocess,re,concurrent.futures,sys,time,urllib.request,os
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));import classify
r=Path(__file__).parent;out=r/'watch';out.mkdir(exist_ok=True)
queue=[]
for n in classify.CHANNELS:
 for v in classify.records(n):
  c=classify.classify(n,v)
  if c['eligible'] is None and not re.search(r'Prices|Information|Infrastructure|Mobility|Mud|Headliners|Warm Up|X-Mas|Infield Opening|Hails from|Mayrhofen|Zombie|Before Joining|Livestream on|last Day|Gedenken|How to keep|Xounts|Sharon.*Stories|Feuer in|Beach|Mowing|Aktien|cool down|Meilen|stamps|Edge of Space|Cruisader|Fans and Artists|Maschinenraum|Rückblick|Day \d|Cruisaders|Winners and Prizes|Service.*Team|Romantic|Good Morning|beer gets|No sleep|quit at|join Wacken|mud of|First Night|taking off|Organizer',v['title'],re.I):queue.append(v['id'])
  if c.get('type')=='program':queue.append(v['id'])

if (r/'bbc-playlist-review.json').exists():
 for v in json.loads((r/'bbc-playlist-review.json').read_text()):
  if classify.classify('bbc',v)['eligible'] is None:queue.append(v['id'])
queue.extend(sys.argv[1:]);queue=list(dict.fromkeys(queue));print('WATCH QUEUE',len(queue),flush=True)
def go(i):
 p=out/(i+'.json')
 if p.exists():return
 try:
  ctx=json.loads(re.search(r'ytcfg.set\((\{.*?\})\);',(r/'wackentv.html').read_text())[1])['INNERTUBE_CONTEXT']
  request=urllib.request.Request('https://www.youtube.com/youtubei/v1/player',data=json.dumps({'context':ctx,'videoId':i,'contentCheckOk':True,'racyCheckOk':True}).encode(),headers={'Content-Type':'application/json','User-Agent':'Mozilla/5.0'})
  op=urllib.request.build_opener(urllib.request.ProxyHandler({'https':os.environ['HTTPS_PROXY']}))
  d=json.loads(op.open(request,timeout=20).read())
  v=d.get('videoDetails',{});micro=d.get('microformat',{}).get('playerMicroformatRenderer',{})
  p.write_text(json.dumps({'id':i,'details':v,'microformat':micro,'playability':d.get('playabilityStatus'),'sourceUrl':'https://www.youtube.com/watch?v='+i},ensure_ascii=False));print(i,'WATCH',bool(v),flush=True)
 except Exception as e:(out/(i+'.error')).write_text(str(e));print(i,'WATCH FAIL',str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=6) as ex:list(ex.map(go,queue))
