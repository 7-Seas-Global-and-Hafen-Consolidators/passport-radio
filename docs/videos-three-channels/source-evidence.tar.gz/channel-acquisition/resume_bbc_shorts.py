import json,os
from pathlib import Path
import yt_dlp
from yt_dlp.extractor.youtube import YoutubeTabIE
R=Path(__file__).parent
out=R/'bbc-shorts-recovered.jsonl'
seen={json.loads(s)['id'] for s in out.read_text().splitlines()} if out.exists() else set()
old=YoutubeTabIE._entries
def entries(self,*args,**kwargs):
 for row in old(self,*args,**kwargs):
  if row.get('id') and row['id'] not in seen:
   with out.open('a') as f:f.write(json.dumps(row,ensure_ascii=False)+'\n');f.flush();os.fsync(f.fileno())
   seen.add(row['id'])
  yield row
YoutubeTabIE._entries=entries
class Log:
 def debug(self,s):
  if 'page' in s.lower():print(s,flush=True)
 def warning(self,s):print(s,flush=True)
 def error(self,s):print(s,flush=True)
opts={'extract_flat':True,'skip_download':True,'socket_timeout':25,'retries':3,'logger':Log()}
if os.getenv('HTTPS_PROXY'):opts['proxy']=os.getenv('HTTPS_PROXY')
with yt_dlp.YoutubeDL(opts) as y:d=y.extract_info('https://youtube.com/@bbcmusic/shorts?si=AqKKglu9JOtvPQqI',download=False)
(R/'bbc-shorts-complete.json').write_text(json.dumps(d,ensure_ascii=False))
print('SHORTS COMPLETE',len(seen),flush=True)
