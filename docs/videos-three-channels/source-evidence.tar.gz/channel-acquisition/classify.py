import json,re,datetime,collections
from pathlib import Path
R=Path(__file__).parent
CHANNELS={'wackentv':'UCvQT6N9nu2BJ-lJuMg1jEZQ','midnight':'UCNF4M2QUP0lpSc32MOP2DZw','bbc':'UCZtDUmC3W7j25XHZWFT_XgQ'}
def flat(x,tab=''):
 if 'entries' in x:
  for a in x['entries']:yield from flat(a,x.get('title',tab))
 else:yield dict(x,tab=tab)
def records(n):
 p=R/(n+'-channel.json')
 if not p.exists():return []
 out={x['id']:dict(x,channel_id=CHANNELS[n]) for x in flat(json.loads(p.read_text()))}
 for p in sorted((R/'playlist-entries').glob('*.json')):
  d=json.loads(p.read_text())
  if d['source']!=n:continue
  for x in flat(d['playlist']):
   if x.get('channel_id') and x['channel_id']!=CHANNELS[n]:continue
   if x['id'] not in out and x.get('channel_id')==CHANNELS[n]:out[x['id']]=x
   if x['id'] in out:out[x['id']].setdefault('memberships',[]).append({'id':d['playlist']['id'],'title':d['playlist']['title']})
 return list(out.values())
def date(t):
 months='January February March April May June July August September October November December'.split()
 m=re.search(r'('+ '|'.join(months)+r')\s+(\d{1,2})[,]?\s+(19\d{2}|20\d{2})',t,re.I)
 if m:
  try:return datetime.date(int(m[3]),[a.lower() for a in months].index(m[1].lower())+1,int(m[2])).isoformat()
  except ValueError:pass
 years=re.findall(r'\b(?:19|20)\d{2}\b',t)
 return years[0] if len(set(years))==1 else None
BAD=r'\b(?:interview|interviews|podcast|trailer|teaser|teasers|advert|announcement|announcements|coming soon|subscribe|behind the scenes|backstage|Harry Metal|after ?movie|documentary|documentaries|comedy|comic|comedian|stand.?up|crowd work)\b'
MIDBAD=['Ace Trucking Company','Kentucky Fried Theater','Couples Communication','Ricky Rendevous','TV Show is Coming','TV Show is BACK','Streaming Now','this Friday','Watch episode','Hall of Fame','Hall Of Fame','Hall of fame','Origins','Band Names','Name Origin','Album Re-Release','Best Duo Ever','Guitar named','Make Up','Grammy Sweep','Movie Star','Teacher','First Band','Made State','State Farm','Imagination Library','Pop Icon','Debut Solo','Last of Us','Breakup Songs','Writing Music','Lost Guitar','Quote','Gold Records','performed at 10','Broadway Star','Animation','made up lyrics','hit from Stevie','went Platinum','Played The Accordion','pay IRS','Angel Outfit','Doesn’t Write','Doesn\'t Write','Jolene Inspiration','Love to Love You, Donna','Motor City Mad Man','KISS Army','Happy 4th']
OV=json.loads((R/'overrides.json').read_text()) if (R/'overrides.json').exists() else {}
def classify(n,v):
 t=v.get('title')or'';i=v['id']
 if i in OV:return OV[i]
 if not re.match(r'^[\w-]{11}$',i) or t in ['[Deleted video]','[Private video]']:return {'eligible':False,'reason':'Unavailable/private/deleted'}
 if re.search(BAD,t,re.I) or n=='midnight' and any(x.lower() in t.lower() for x in MIDBAD):return {'eligible':False,'reason':'Title identifies non-performance, interview, comedy, promotion or administration'}
 if n=='midnight':
  prog=re.search(r'\bEp\s*(\d+[A-Za-z]?)',t,re.I)
  if prog:return {'eligible':True,'artist':'Vários artistas','title':'Episódio '+prog[1]+' · programa completo','type':'program','showDate':date(t),'evidence':'Full-episode designation in original title; no upload date substituted'}
  s=re.sub(r'\s*(?:[|I]\s*|[-–]\s*|\s+)(?:The|Tee) Midnight Special.*$', '',t,flags=re.I).strip()
  s=re.sub(r'\s*[|–-]?\s*(?:January|February|March|April|May|June|July|August|September|October|November|December)\s+\d{1,2},?\s+\d{4}.*$','',s,flags=re.I).strip()
  s=re.sub(r'\s*[|]\s*The Midnight$','',s,flags=re.I).strip()
  s=re.sub(r'\s*#shorts\b','',s,flags=re.I).strip()
  if ' - ' in s:
   a,b=s.rsplit(' - ',1)
   # The channel normally uses song — artist; its occasional artist-first entries require overrides.
   return {'eligible':True,'artist':b.strip(),'title':a.strip(),'type':'performance','showDate':date(t),'evidence':'Song/artist identified by original performance title'}
  if ' – ' in s:
   a,b=s.split(' – ',1);return {'eligible':True,'artist':a.strip(),'title':b.strip(),'type':'performance','showDate':date(t),'evidence':'Artist/song identified by original performance title'}
  return {'eligible':None,'reason':'Needs contextual title/description review'}
 if n=='wackentv':
  if re.search(r'Q&A|\bFAQ\b|recap|highlights|camping|campground|Impressions|Flashback|vlog|Outro|Festival Credits|Welcome|\bFeature\b|XR-Stage|Peer Camps|Innovation|New Bands|New Acts|Variety of|Variety at|Swimming|Cook|Yoga|Merchandise|Ticket|Thank You|Subscriptions|Weather|Sanitary|Fashionweek|Camplife|Foundation|Pre-Show-Talk|Wine tasting|Skiers|Paragliding|Trainingslager|Drone Shows|Greetings|Thomas.*Holger|Line-Up|Looking back|Donor|Inclusion|Christmas|Travel Shop|Days until|\bWacken.*brings\b|Wacken.*\bhas\b|Wacken.*\bjoin\b|Wacken.*\bquit\b|Wacken.*piratical|New Year|wine|bracelets|News|Video.host|Custom Bike|Wilderness|protect|Vikings vs|Metalympics|Wrestling|Headbang fun|Mudfighters|Aerial Shots|Emotions|Numbers|Commandments|beach chairs|Strandkörbe|Bülent Ceylan|Masters Of Dirt|StrongmanRun|Production looking|Day \d at Full Metal|Day \d in 30|Baking|Calm Before|Emotional Infield|Arrival|Access Pass|Music Camp|Waldfestplatz|Kasermandl|Wheels of Steel|Green Wacken|Cashless|Red Cross|Bus Station',t,re.I):
   return {'eligible':False,'reason':'Reviewed festival administration, promotional news, vlog, scenery or recap rather than a musical presentation'}
  s=re.sub(r'\s*[|]\s*(?:WackenTV|Wacken TV).*$', '',t,flags=re.I)
  m=re.match(r'(.+?)\s*\|\s*(.+)|(.+?)\s+[-–—]\s+(.+)',s)
  if m and not re.search(r'\b(?:festival diary|campground|camping|press conference|recap|announcement|highlights|best of|bands for|line.?up|Q&A|\bFAQ\b|greetings|Impressions|Flashback|vlog|Outro|Festival Credits|Welcome|\bFeature\b|XR-Stage|Peer Camps|Innovation|New Bands|New Acts|Variety of|Variety at|Swimming|Cook|Yoga|Merchandise|Ticket|Thank You|Subscriptions|Weather|Sanitary|Fashionweek|Camplife|Foundation|Pre-Show-Talk|Wine tasting|Skiers|Paragliding|Trainingslager|Drone Shows)\b',s,re.I):
   a,b=(m[1],m[2]) if m[1] else (m[3],m[4]);
   if re.match(r'(?:Wacken Open Air|Full Metal(?: Cruise| Holiday| Mountain)|You Metal\?|Annual review)',a,re.I):return {'eligible':None,'reason':'Festival format or compilation needs contextual review'}
   return {'eligible':True,'artist':a.strip(),'title':b.strip(),'type':'full-concert' if re.search(r'full (?:show|concert|set)|complete (?:show|concert|set)',s,re.I) else 'performance','showDate':date(s),'evidence':'Artist/performance title; contextual exclusions reviewed separately'}
  return {'eligible':None,'reason':'Needs contextual title/description review'}
 if n=='bbc':
  if re.search(r'\b(?:talks?|chats?|quiz|quizzes|reacts?|reaction|explains?|discuss|discussion|conversation|advice|tips|guided tour|highlights|round.up|preview|trivia|challenge|guess|guessing|behind|meet|watch out|thank you|join us|announc|coming|new year|how to|celebrates?|journey|remembering|remember|memories|tribute to|favourite|favorite|best moments|best bits)\b',t,re.I):
   return {'eligible':False,'reason':'Title identifies talk, interview, promotional montage, trivia, backstage or announcement rather than a performance'}
  s=re.sub(r'\bBBC(?: Music)?(?: Radio [1-6])?\s*(?:Introducing\s*)?(?:at\s*)?', '',t,flags=re.I)
  s=re.sub(r'\s*[-|]\s*(?:Radio [1-6]|Music)\s*$','',s).strip(' |–-')
  m=re.match(r'(.+?)\s+[-–—]\s+(.+)',s)
  if m:
   a,b=m.groups()
   return {'eligible':True,'artist':a.strip(),'title':b.strip(' |–-'),'type':'full-concert' if re.search(r'full (?:show|concert|set)|complete (?:show|concert|set)',t,re.I) else 'performance','showDate':date(t),'evidence':'Original artist/song title in the acquired music-performance channel; administrative/talk exclusions applied first'}
  m=re.match(r"(.+?)\s+performs?\s+(.+)",s,re.I)
  if m:return {'eligible':True,'artist':m[1].strip(),'title':m[2].strip(),'type':'performance','showDate':date(t),'evidence':'Explicit performance designation in acquired original title'}
  m=re.match(r'(.+?)\s+(?:at|in session|\()\s*(.*)',s,re.I)
  if m and re.search(r'Glastonbury|Reading|Leeds|session|Eurosonic|SXSW|Escape|Weekend|Latitude|Festival|Piano Room|Proms|Introducing',t,re.I):
   return {'eligible':True,'artist':m[1].strip(),'title':m[2].strip(' ()') or 'In session','type':'performance','showDate':date(t),'evidence':'Artist and performance/session/festival identified by original title'}
  return {'eligible':None,'reason':'Needs contextual title/description review'}
if __name__=='__main__':
 for n in CHANNELS:
  v=records(n);rows=[dict(id=x['id'],originalTitle=x.get('title'),**classify(n,x)) for x in v];counts=collections.Counter(x['eligible'] for x in rows);print(n,len(rows),counts)
  (R/(n+'-draft.json')).write_text(json.dumps(rows,ensure_ascii=False,indent=2));(R/(n+'-review.txt')).write_text('\n'.join(str(x) for x in rows if x['eligible'] is None))
