"""Append reviewed channel acquisitions without modifying any existing public record."""
import json,hashlib,collections,datetime,re
from pathlib import Path
from classify import CHANNELS,records,classify
R=Path(__file__).parent;repo=R.parent/'videos-channels'
baseline=json.loads((R/'baseline-catalogue.json').read_text()); catalogue=json.loads(json.dumps(baseline));seen={v['id'] for v in catalogue['videos']};original=set(seen);audit=[];counts={};cols={'wackentv':('festival-archive','Festivais ao vivo'),'midnight':('tv-archive','Arquivo musical de TV'),'bbc':('sessions-archive','Sessões e festivais')}
for n in CHANNELS:
 source=R/(n+'-channel.json');assert source.exists(),f'Unfinished source {n}'
 rows=records(n);counts[n]={'traversed':len(rows),'eligible':0,'alreadyExisting':0,'added':0,'excluded':0,'duplicatesAvoided':0}
 collection,label=cols[n];catalogue['collections'].append({'id':collection,'label':label})
 for position,v in enumerate(rows,1):
  q=classify(n,v);assert q['eligible'] is not None,(n,v['id'],'Unresolved review')
  record={'id':v['id'],'source':n,'channelId':CHANNELS[n],'originalUrl':'https://www.youtube.com/watch?v='+v['id'],'originalTitle':v.get('title'),'memberships':v.get('memberships',[]),'acquiredEntry':v,'classification':q}
  p=R/'watch'/(v['id']+'.json')
  if p.exists():record['context']=json.loads(p.read_text())
  if not q['eligible']:
   record['disposition']='excluded';counts[n]['excluded']+=1
  else:
   counts[n]['eligible']+=1
   if v['id'] in seen:
    record['disposition']='already-present';counts[n]['duplicatesAvoided']+=1
    if v['id'] in original:counts[n]['alreadyExisting']+=1
   else:
    assert q['artist'].strip() and q['title'].strip()
    item={'id':v['id'],'artist':q['artist'],'title':q['title'],'showDate':q.get('showDate'),'type':q['type'],'collections':[collection],'collectionOrder':{collection:position},'embedAllowed':True,'thumbnail':'https://img.youtube.com/vi/'+v['id']+'/hqdefault.jpg'}
    assert not re.search(r'WackenTV|BBC Music|YouTube',item['artist']+' '+item['title'],re.I),item
    catalogue['videos'].append(item);seen.add(v['id']);record['disposition']='added';counts[n]['added']+=1
  audit.append(record)
assert catalogue['videos'][:len(baseline['videos'])]==baseline['videos']
summary={'baseHead':'72c76dbbbf32e1d3b63a6dc0f84f4c463a3c3fc7','baselineCount':len(baseline['videos']),'finalCount':len(catalogue['videos']),'sources':counts,'originalCatalogueSha256':hashlib.sha256((R/'baseline-catalogue.json').read_bytes()).hexdigest(),'limits':['YouTube hides unavailable playlist entries without exposing their IDs; only available enumerated records can be inventoried.','Channel metadata and context were acquired without downloading video media. Embed playback remains subject to provider availability.']}
(repo/'data/passport-videos.json').write_text(json.dumps(catalogue,ensure_ascii=False,indent=2)+'\n')
(repo/'data/passport-videos-channel-audit.json').write_text(json.dumps({'summary':summary,'records':audit},ensure_ascii=False,indent=2)+'\n')
(repo/'docs/videos-three-channels/counts.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n')
print(json.dumps(summary,ensure_ascii=False,indent=2))
