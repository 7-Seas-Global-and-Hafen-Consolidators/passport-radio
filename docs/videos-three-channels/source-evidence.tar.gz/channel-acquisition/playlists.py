import yt_dlp,json,os,concurrent.futures
from pathlib import Path
r=Path(__file__).parent
channels={'wackentv':'@wackentv','midnight':'@themidnightspecialtvshow','bbc':'@bbcmusic'}
def collect(item):
 n,h=item;p=r/(n+'-playlists.json')
 if p.exists():return
 class Log:
  def debug(self,m):
   if 'page ' in m:print(n,m,flush=True)
  def warning(self,m):print(n,'WARNING',m,flush=True)
  def error(self,m):print(n,'ERROR',m,flush=True)
 try:
  with yt_dlp.YoutubeDL({'extract_flat':True,'skip_download':True,'proxy':os.environ['HTTPS_PROXY'],'socket_timeout':20,'retries':2,'logger':Log()}) as y:
   d=y.extract_info('https://www.youtube.com/'+h+'/playlists',download=False)
  p.write_text(json.dumps(d,ensure_ascii=False));print(n,'PLAYLIST DIRECTORY DONE',len(d['entries']),flush=True)
 except Exception as e:(r/(n+'-playlists-error.txt')).write_text(str(e));print(n,'PLAYLIST FAIL',str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as ex:list(ex.map(collect,channels.items()))
