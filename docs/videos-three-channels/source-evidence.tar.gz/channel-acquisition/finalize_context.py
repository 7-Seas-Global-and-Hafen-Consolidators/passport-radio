import json,re
from pathlib import Path
from classify import records,classify,date
R=Path(__file__).parent; ov=json.loads((R/'overrides.json').read_text())
def yes(i,a,t,typ='performance',d=None,e='Context reviewed against acquired title and description'):
 ov[i]={'eligible':True,'artist':a,'title':t,'type':typ,'showDate':d,'evidence':e}
def no(i,why):ov[i]={'eligible':False,'reason':why}
for i in ['0fVTKaQUN3o','fEDBQY2K9sI','f7upPcfkb0Y','GFG-z--KvPU','XG-tV6uwZXM','wsHxcSecoWM','eMXSWd8qlug','pML9BsdAIiY','trUUAKa_K-k','mofo0gSZqTE']:
 no(i,'Acquired description identifies promotional/backstage/trivia/travel/talk content, not a musical performance')
yes('HWH7tjm5IOI','Matt Heafy e Cemican','30th Anniversary Show · Wacken Open Air')
yes('hVkbC6DUeYs','Bannkreis','Wacken Open Air 2018',d='2018')
yes('8Qdjn9bBRj8','Eric Fish','Wacken Metal Church 2014',d='2014')
yes('BDDhALjSMe4','In Extremo, Mr. Hurley & Die Pulveraffen, Elvenking e Skyclad','Wacken Winter Nights Digital','program','2021-02-20')
yes('19URx79_Yiw','Any Given Day','Savior · Wacken Open Air 2026',d='2026')
for i in ['OqWEZX-xohw','xOleDMbdVq8']:no(i,'Competition/report coverage; acquired metadata does not establish a standalone musical performance')
yes('tXpjSiMuRkU','Cloudy Yang, Thomas Rettke e Oliver Hartmann','Hard On The Wind',e='Original musical recording: acquired description names composer Sascha Paeth and the three singers')
for n in ['midnight','wackentv']:
 for v in records(n):
  q=classify(n,v); p=R/'watch'/(v['id']+'.json')
  if not p.exists():continue
  w=json.loads(p.read_text());desc=w.get('details',{}).get('shortDescription','')or''
  if n=='midnight' and q.get('type')=='program':
   artists=[]
   for line in desc.splitlines():
    m=re.match(r'\s*(?:\d+:)?\d+:\d+\s+(.+?)\s+[-–]\s+',line)
    if m and m[1] not in artists and not re.search(r'intro|outro|comedy|commercial',m[1],re.I):artists.append(m[1])
   q=dict(q,showDate=date(desc.split('\n\n')[0]) or q.get('showDate'),evidence='Complete programme designation and acquired episode description/chapter credits')
   if artists:q['artist']=', '.join(artists[:3])+(' e outros' if len(artists)>3 else '')
   ov[v['id']]=q
# Only names/titles established by this same channel's acquired archive, no guessed song/date.
yes('xX5FFegH-zk','Vários artistas','Salute to David Bowie','program','1975-09-19')
no('7DWN5n_pKec','Joan Rivers comedy/talk segment: no musical performance established by acquired metadata')
yes('9SuCTOWO54k','Ray Charles e Carol Burnett','Ray Charles and Carol Burnett',d='1973-03-30')
yes('8mIt9Y2y_Qk','Barry White','Barry White')
yes('bRkkH5sKCK8','Barry Manilow e Bathhouse Betty','Barry Manilow & Bathhouse Betty')
yes('VL3FRzxZTjY','Peter Frampton','Talk Box')
for i,song in [('CA7WRsu1ATk','Sister Golden Hair'),('Ph4pAkHis70','Everlasting Love')]:
 matches=[classify('midnight',v) for v in records('midnight') if song.lower() in (v.get('title')or'').lower() and v['id']!=i]
 a=[q['artist'] for q in matches if q.get('eligible') and q.get('artist')]
 if len(set(a))==1:yes(i,a[0],song,e='Song and artist confirmed by corresponding separately published performance in the acquired same-channel archive')
 else:no(i,'Song title without a verifiable artist in acquired metadata; withheld rather than inventing identity')
(R/'overrides.json').write_text(json.dumps(ov,ensure_ascii=False,indent=2))
