import pathlib,json,urllib.request,concurrent.futures
R=pathlib.Path(__file__).parent;d=json.load(open(R.parent/'videos-channels/data/passport-videos.json'));out=R/'thumbnails';out.mkdir(exist_ok=True);v=d['videos'][:24]
for c in ['festival-archive','tv-archive','sessions-archive']:v.extend([x for x in d['videos'] if c in x['collections']][:24])
def go(v):
 p=out/(v['id']+'.jpg')
 if p.exists():return
 try:p.write_bytes(urllib.request.urlopen(v['thumbnail'],timeout=25).read())
 except Exception as e:print(v['id'],str(e),flush=True)
with concurrent.futures.ThreadPoolExecutor(max_workers=8) as pool:list(pool.map(go,v))
print('Cached',len(list(out.glob('*.jpg'))),flush=True)
